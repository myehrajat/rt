<?php
/**
 * @package RentIt_Date_Changer
 * @version 1.0
 */
//include_once(plugin_dir_path(__FILE__) . 'enqueue_backend_dates.php');
//include_once(plugin_dir_path(__FILE__) . 'enqueue_frontend_dates.php');
include_once(plugin_dir_path(__FILE__) . 'enqueue_bothside_dates.php');

