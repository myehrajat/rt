window.Date= pDate;
//https://wordpress.stackexchange.com/questions/93732/using-get--javascriptoption-in to know how momentVars passed
///alert(momentVars.cal_lang);