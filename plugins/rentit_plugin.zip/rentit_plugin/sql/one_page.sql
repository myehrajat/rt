REPLACE INTO `rentitop_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(4809, 'rentit_one_page_menu', '<li><a href="#who-we-are">who we are</a></li><li><a href="#Offers">Offers</a></li><li><a href="#our-cars">Our Cars</a></li><li><a href="#FAQS">FAQS</a></li><li><a href="#Find-a-Car">Find a Car</a></li>', 'yes');

REPLACE INTO `rentitop_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(4810, 'rentit_one_page_menu_right', '<li><a href="#Help-Desk">Help Desk</a></li><li><a href="#Contact">Contact</a></li>', 'yes');
